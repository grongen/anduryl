"""Top-level package for delft3dfmpy."""

__author__ = """Guus Rongen, Marcel 't Hart, Georgios Leontaris, Oswaldo Morales Nápoles"""
__email__ = "g.w.f.rongen@tudelft.nl"
__version__ = "1.2.2"

# Import the Project class
# from anduryl import core
from anduryl.core.main import Project
